# BERT

- [BERT](BERT)
  - [1. 简介](#1-简介)
  - [2. 数据集](#2-数据集)
  - [3. 准备模型与数据](#3-准备模型与数据)
  - [4. 模型编译](#4-模型编译)
    - [4.1 生成FP32 BModel](#41-生成fp32-bmodel)
    - [4.2 生成INT8 BModel](#42-生成int8-bmodel)
  - [5. 例程测试](#5-例程测试)


## 1. 简介

​BERT的全称为Bidirectional Encoder Representation from Transformers，是一个预训练的语言表征模型。它强调了不再像以往一样采用传统的单向语言模型或者把两个单向语言模型进行浅层拼接的方法进行预训练，而是采用新的masked language model（MLM），以致能生成深度的双向语言表征。BERT论文发表时提及在11个NLP（Natural Language Processing，自然语言处理）任务中获得了新的state-of-the-art的结果，令人目瞪口呆。
A simple training framework that recreates bert4keras in PyTorch. bert4torch


**文档:** [BERT文档](https://bert4torch.readthedocs.io/)

**参考repo:** [BERT](https://github.com/Tongjilibo/bert4torch)

**实现repo：**[BERT](https://github.com/Tongjilibo/bert4torch)

## 2. 数据集

NER基于[china-people-daily](http://s3.bmio.net/kashgari/china-people-daily-ner-corpus.tar.gz)，我们选择 1998 年人民日报语料库作为数据集，该语料库标注了大量的语言学信息，可以同时用于分词、NER 等任务。这里我们直接使用处理好的 NER 语料 china-people-daily-ner-corpus.tar.gz。
该语料已经划分好了训练集、验证集和测试集，分别对应 example.train、example.dev 和 example.test 文件，包含 20864 / 2318 / 4636 个句子。
## 3. 准备模型与数据

​Pytorch的模型在编译前要经过`torch.jit.trace`，trace后的模型才能用于编译BModel，trace方法可以采用官方`export.py`。

​同时，您需要准备用于测试的数据集，如果量化模型，还要准备用于量化的数据集。

​本例程在`scripts`目录下提供了相关模型和数据（后续demo会使用）的下载脚本`download.sh`，您也可以自己准备模型和数据集，并参考[4. 模型编译](#4-模型编译)进行模型转换。

```bash
cd scripts
chmod +x ./*
bash download.sh
```

​执行后，模型保存至`data/models`，数据集下载并解压至`data/`

```
下载的模型包括：
./models/
├── BM1684
│   └── BERT_NER_output_fp32_1b.bmodel
├── BM1684X
│   └── BERT_NER_output_fp32_1b.bmodel
└── torch
    └── bert4torch_jit.pt
./pre_train/
└── vocab.txt
下载的数据包括：
./china-people-daily-ner-corpus
├── example.dev                                              # 验证集
├── example.test                                             # 测试集
└── example.train                                            # 训练集
             
```

​模型信息：

| 模型名称 | [BERT4torch](https://github.com/sophgo/model-zoo/blob/main/language/nlp/bert/bert4torch_jit.pt) |
| :------- | :----------------------------------------------------------- |
| 训练集   | china-people-daily-ner-corpus                                 |
| 概述     | 人民日报NER                                                   |
| 运算量   | 16.5 GFlops                                                  |
| 输入数据 | 文本, [batch_size, 256], FP32 string   |
| 输出数据 | scores, [batch_size, 256,7], mask <br />391, [batch_size, 3, 4256], FP32  <br />
| 前处理   | 分词，pad，编码等                                             |
| 后处理   | crf,softmax等                                                |

## 4. 模型编译

​trace后的pytorch模型需要编译成BModel才能在SOPHON TPU上运行，如果使用下载好的BModel可跳过本节。

模型编译前需要安装TPU-NNTC，具体可参考[tpu-nntc环境搭建](../docs/Environment_Install_Guide.md#1-tpu-nntc环境搭建)。安装好后需在tpu-nntc环境中进入例程目录。

### 4.1 生成FP32 BModel

​本例程在`scripts`目录下提供了编译FP32 BModel的脚本。请注意修改`gen_fp32bmodel.sh`中的JIT模型路径、生成模型目录和输入大小shapes等参数，并在执行时指定BModel运行的目标平台（支持BM1684和BM1684X），如：

```bash
cd scripts
chmod +x ./*
bash gen_fp32bmodel.sh BM1684X
```

​执行上述命令会在`data/models/BM1684X/`下生成`compline.bmodel`文件，即转换好的FP32 BModel。


## 5. 例程测试

- [C++例程](./cpp/README.md)
- [Python例程](./python/README.md)