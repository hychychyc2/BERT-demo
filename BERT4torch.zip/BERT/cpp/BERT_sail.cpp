#define USE_FFMPEG  1
#define USE_OPENCV  1
#define USE_BMCV    1
#include "BERT_sail.hpp"
#include <stdio.h>
#include <sail/cvwrapper.h>
#include <sail/tensor.h>
#include <sail/engine.h>
#include <iostream>
#include <fstream>
#include <string>
// #include <torch/script.h> // One-stop header.
// #include<torch/csrc/api/include/torch/utils.h>
#include <memory>
#include <bits/stdc++.h>
#include "opencv2/opencv.hpp"


using namespace std;

// BertTokenizer tokenizer;

map<string,int> text2id;
map<int,string> id2text;

BERT::BERT(string model_path,string pre_train_path){
    device_id=0;
    mode=sail::SYSO;
    handle=new sail::Handle(device_id);
    bmcv=new sail::Bmcv(*handle);
    engine=new sail::Engine(model_path,*handle,mode);
    graph_name=engine->get_graph_names()[0];
    input_name=engine->get_input_names(graph_name)[0];
    output_names=engine->get_output_names(graph_name);
    input_shape=engine->get_input_shape(graph_name,input_name);
    input_dtype=engine->get_input_dtype(graph_name,input_name);
    // cout<<"]]]]]]]]]]]]]"<<input_dtype;
    input_scale=(engine->get_input_scale(graph_name,input_name));
    
    tokenizer.add_vocab(pre_train_path.c_str());
    tokenizer.maxlen_=256;
    tokenizer.do_lower_case_=1;
    input_tensor=sail::Tensor(*handle,input_shape,input_dtype,1,1);
    for(int i=0;i<output_names.size();i++){
        
        output_shape.push_back(engine->get_output_shape(graph_name,output_names[i]));
        output_dtype.push_back(engine->get_output_dtype(graph_name,output_names[i]));
        output_scale.push_back(engine->get_output_scale(graph_name,output_names[i]));
        output_tensors.push_back(sail::Tensor(*handle,output_shape[i],output_dtype[i],1,1));
    }
    id2label.push_back("O");id2label.push_back("B-LOC");
    id2label.push_back("I-LOC");id2label.push_back("B-PER");
    id2label.push_back("I-PER");id2label.push_back("B-ORG");
    id2label.push_back("I-ORG");
};
  
    
   
    void BERT::pre_process(string text){
        text="[CLS]"+text+"[SEP]";
        tokens=tokenizer.tokenize(text);
        token_ids = tokenizer.convert_tokens_to_ids(tokens);
        
        for(int i=token_ids.size();i<256;i++)
        token_ids.push_back(0),tokens.push_back("[PAD]");//cout<<token_ids;
        return;

    }
int BERT::Detect()
{

    std::map<std::string, sail::Tensor *> input=engine->create_input_tensors_map(graph_name,-1);
    //float * tmp= (float *)&token_ids;
    //cout<<input_shape;
    input_tensor.reset_sys_data(token_ids.data(),input_shape);
    input_tensor.sync_s2d();
    // float * tmp= (float*)input_tensor.sys_data();
    // cout<<"-------"<<endl;
    // for(int i=0;i<256;i++)cout<<' '<<tmp[i];
    input[input_name]= &input_tensor;
    
    //cout<<input.size()<<endl;
    std::map<std::string, sail::Tensor *> output=engine->create_output_tensors_map(graph_name,-1);
    for (int i=0;i<output_names.size();i++){
        output[output_names[i]]=&output_tensors[i];
    }
    //output[output_name]= &output_tensor;
    engine->process(graph_name,input,output);//cout<<"-------"<<endl;
      //cout<<((float*)output_tensor.sys_data())[777];//0.0034362
    for (int i=0;i<output_names.size();i++){
        output_tensors[i].sync_d2s();
    }
    //cout<<output_tensors[0].shape();
    //cout<<"-------"<<endl;
    post_process();
    return 1;
}
 void BERT::softmax(float* x, int length)
{
	float sum = 0;
	int i = 0;
	for (i = 0; i < length; i++)
	{
		x[i] = exp(x[i]);
		sum += x[i];
	}
	for (i = 0; i < length; i++)
	{
		x[i] /= sum;
	}
}
vector<string> BERT::post_process()
{
    float *tmp= (float*)output_tensors[0].sys_data();
    string s="";
    vector<string> ans;
    //cout<<1;
    for (int i=0;i<256;i++){
        if(tokens[i]=="[PAD]")break;
        softmax(tmp,7);
        
        int id=0;
        //cout<<i;
        // if(i==17||i==18){
        //     for(int j=0;j<7;j++)cout<<tmp[j]<<' ';
        //     //cout<<i;
        // }
        
        for(int j=1;j<7;j++)
        if(tmp[id]<tmp[j]) id=j;
        if(id2label[id][0]=='B'){
            if(s.length())
            ans.push_back(s),s="";
            s=tokens[i];
            
        }else if(id2label[id][0]=='I'){
            s+=tokens[i];
            
        }else{
            
            if(s.length())
            ans.push_back(s),s="";
        }
        tmp+=7;
    }
  return ans;
}



int main(int argc, char *argv[])
{
  const char *keys="{bmodel | ../../data/models/BM1684/fp32model/compilation.bmodel | bmodel file path}"
    "{tpuid | 0 | TPU device id}"
    "{dict_path | ../../data/pre_train/chinese-bert-wwm/vocab.txt | pre train vab path}"
    "{help | 0 | Print help information.}";


  cv::CommandLineParser parser(argc, argv, keys);
  if (parser.get<bool>("help")) {
    parser.printMessage();
    return 0;
  }

  std::string bmodel_file = parser.get<std::string>("bmodel");
  int dev_id = parser.get<int>("tpuid");
  std::string dict_path = parser.get<std::string>("dict_path");
  BERT bert(bmodel_file,dict_path);

    // read_vocab("/workspace/Release_221201-public/sophon-demo_20221227_085900/sophon-demo_v0.1.2_03507ae_20221227/sample/BERT/data/pre_train/chinese-bert-wwm/vocab.txt");
    // for(auto i:text2id){
    //     //cout<<i.first<<' '<<i.second<<endl;
    // }
    //   std::cout<<std::endl;
    while(1){
        string input;
        cin>>input;
        bert.pre_process(input);
        bert.Detect();
        vector<string> ans=bert.post_process();
        for(auto i:ans){
            cout<<i<<endl;
        }
    }
    
    return 0;
}