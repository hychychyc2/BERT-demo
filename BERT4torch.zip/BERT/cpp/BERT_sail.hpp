
#include <stdio.h>
#include <sail/cvwrapper.h>
#include <sail/tensor.h>
#include <sail/engine.h>
#include <iostream>
#include <string>
#include "tokenizer.h"
using namespace std;



class BERT {
    
  
    public:
    BERT(string model_path,string pre_train_path);
    void pre_process(string text);

    int Detect();
     vector<string>  post_process();
    void softmax(float* x, int length);
    private:
    sail::IOMode mode;
    sail::Handle *handle;
    sail::Bmcv *bmcv;
    sail::Engine *engine;
    int device_id;
    // float input_scale;
    string graph_name;
    string input_name;
    vector<string> output_names;
    vector<int> input_shape;
    bm_data_type_t input_dtype;
    float input_scale;
    vector<vector<int> > output_shape;
    vector<bm_data_type_t> output_dtype;
    bm_image_data_format_ext img_dtype;
    vector<float> output_scale;
    BertTokenizer tokenizer;
    sail::Tensor input_tensor;
    vector<sail::Tensor> output_tensors;
    vector<string> tokens;
    vector<float> token_ids;
    vector<string> id2label;
};
