# C++例程
- [C++例程](#c例程)
  - [1. 目录说明](#1-目录说明)
  - [2. 程序编译](#2-程序编译)
  - [2.1 PCIE模式](#21-pcie模式)
    - [2.1.1 环境准备](#211-环境准备)
    - [2.1.2 程序编译](#212-程序编译)
  - [2.2 SOC模式](#22-soc模式)
    - [2.2.1 环境准备](#221-环境准备)
    - [2.2.2 交叉编译](#222-交叉编译)
  - [3. 测试](#3-测试)

## 1. 目录说明

​cpp目录下提供了C++例程以供参考使用，目录结构如下：

```
cpp
├── BERT_sail.cpp
├── BERT_sail.hpp
├── CMakeLists.txt    # cmake编译脚本
└── README.md

```

## 2. 程序编译

## 2.1 PCIE模式

### 2.1.1 环境准备

如果您在x86平台安装了PCIe加速卡，并使用它测试本例程，您需要安装libsophon、sophon-opencv和sophon-ffmpeg,具体步骤可参考[x86-pcie平台的开发和运行环境搭建](../../docs/Environment_Install_Guide.md#2-x86-pcie平台的开发和运行环境搭建)。

### 2.1.2 程序编译

​C++程序运行前需要编译可执行文件，命令如下：

```bash
cd cpp
mkdir build
cd build
rm ./* -rf
cmake ..
make
```

​运行成功后，会在build目录下生成可执行文件，如下：

```
cpp
├──......
└── build/BERT_sail_demo.pcie    #可执行程序
```

## 2.2 SOC模式

### 2.2.1 环境准备

对于SoC平台，内部已经集成了相应的libsophon、sophon-opencv和sophon-ffmpeg运行库包，位于`/opt/sophon/`下。
需要交叉编译sail，具体步骤可参考[x86-pcie平台的开发和运行环境搭建](../../docs/Environment_Install_Guide.md#2-x86-pcie平台的开发和运行环境搭建)。

### 2.2.2 交叉编译


具体先下载bootsp-1.65.0版本，编译
wget https://boostorg.jfrog.io/artifactory/main/release/1.65.0/source/boost_1_65_0.tar.gz
tar -zxvf boost_1_65_0.tar.gz
./bootstrap.sh --prefix=your_output_path
修改project-config.jam的using gcc一行
 using gcc : : /usr/bin/aarch64-linux-gnu-gcc ; 
 ./bjam
 ./bjam install
将他们的include和lib放到cpp文件目录
提供download_boost.sh脚本



```bash
cd cpp
mkdir build
cd build
rm ./* -rf
cmake -DTARGET_ARCH=soc -DSDK={实际soc sdk路径} ..
make
```

​运行成功后，会在build目录下生成可执行文件，如下：

```
cp
├──......
└── build/BERT_sail.soc    #可执行程序
```



## 3. 测试

可执行程序默认有一套参数，请注意根据实际情况进行传参，具体参数说明如下：
optional arguments:
  --bmodel BMODEL            bmodel path
  --dev_id DEV_ID           device id
  --dict_path dict_path     pre_train_vab_path
```bash

```bash
Usage: BERT_sail_demo.pcie/soc 

```
