import os
import sophon.sail as sail
import torch
import argparse

from utils.dataset import MyDataset
from bert4torch.snippets import sequence_padding, Callback, ListDataset, seed_everything
import numpy as np
from bert4torch.layers import CRF
from bert4torch.tokenizers import Tokenizer
from collections import OrderedDict
from seqeval.metrics import f1_score
from seqeval.metrics import precision_score
from seqeval.metrics import accuracy_score
from seqeval.metrics import recall_score
from seqeval.metrics import classification_report

maxlen = 256
categories = ['O', 'B-LOC', 'I-LOC', 'B-PER', 'I-PER', 'B-ORG', 'I-ORG']
categories_id2label = {i: k for i, k in enumerate(categories)}
categories_label2id = {k: i for i, k in enumerate(categories)}
dataset=MyDataset()
# D=dataset.load_data("../data/china-people-daily-ner-corpus/example.test")
#print(D[0])

# # output_dir="../data/output/"
# bmodel_path='/workspace/Release_221201-public/sophon-demo_20221227_085900/sophon-demo_v0.1.2_03507ae_20221227/sample/nanodet/python/bmodel/fp322/compilation.bmodel'
# bmodel_path="/workspace/Release_221201-public/sophon-demo_20221227_085900/sophon-demo_v0.1.2_03507ae_20221227/sample/BERT/data/models/BM1684/fp32model/compilation.bmodel"

class BERT:
    def __init__(self,model_path,dict_path):
        self.io_mode = sail.IOMode.SYSIO
        self.device=0
        self.engine=sail.Engine(model_path,self.device,self.io_mode)
        self.handle=self.engine.get_handle()
        self.bmcv=sail.Bmcv(self.handle)
        self.graph_names=self.engine.get_graph_names()
        self.input_names={}
        self.output_names={}
        self.max_input_shape={}
        self.input_shapes={}
        self.input_dtypes={}
        self.img_dtypes={}
        self.input_scales={}
        self.max_output_shape={}
        self.output_shapes={}
        self.output_dtypes={}
        self.output_scales={}
        self.dict_path=dict_path

        self.tokenizer = Tokenizer(self.dict_path,do_lower_case=True)
        self.crf = CRF(len(categories))
        self.token2text={}
    
      
    
        for graph_name in self.graph_names:
            self.input_names[graph_name]=self.engine.get_input_names(graph_name)
            self.output_names[graph_name]=self.engine.get_output_names(graph_name)
            self.max_input_shape[graph_name]=self.engine.get_max_input_shapes(graph_name)
            input_shape_dict={}
            for input_name in self.input_names[graph_name]:
                input_shape_dict[input_name]=self.engine.get_input_shape(graph_name,input_name)
            self.input_shapes[graph_name]=input_shape_dict
            output_shape_dict={}
            for output_name in self.output_names[graph_name]:
                output_shape_dict[output_name]=self.engine.get_output_shape(graph_name,output_name)
            self.output_shapes[graph_name]=output_shape_dict
            input_dtype_dict={}
            img_dtypes_dict={}
            for input_name in self.input_names[graph_name]:
                input_dtype_dict[input_name]=self.engine.get_input_dtype(graph_name,input_name)
                img_dtypes_dict[input_name] = self.bmcv.get_bm_image_data_format(input_dtype_dict[input_name])
                
            self.input_dtypes[graph_name]=input_dtype_dict
            self.img_dtypes[graph_name]=img_dtypes_dict
            output_dtype_dict={}
            for output_name in self.output_names[graph_name]:
                output_dtype_dict[output_name]=self.engine.get_output_dtype(graph_name,output_name)
            self.output_dtypes[graph_name]=output_dtype_dict
            input_scale_dict={}
            for input_name in self.input_names[graph_name]:
                input_scale_dict[input_name]=self.engine.get_input_scale(graph_name,input_name)
            self.input_scales[graph_name]=input_scale_dict
            output_scale_dict={}
            for output_name in self.output_names[graph_name]:
                output_scale_dict[output_name]=self.engine.get_output_scale(graph_name,output_name)
            self.output_scales[graph_name]=output_scale_dict
            
   
    def pre_process_1(self,input):

        tokenizer=self.tokenizer
     
        tokens = tokenizer.tokenize(input, maxlen=maxlen)
        token_ids = tokenizer.tokens_to_ids(tokens)
        for i in range(len(tokens)):
            self.token2text[token_ids[i]]=tokens[i]
        for i in range(maxlen-len(token_ids)):
            token_ids.append(0)
        return token_ids
    def pre_process_batch(self,inputs):
        token_ids_, labels_ = [], []
        tokenizer=self.tokenizer
        for d in inputs:
            tokens = tokenizer.tokenize(d[0], maxlen=maxlen)
            mapping = tokenizer.rematch(d[0], tokens)
            start_mapping = {j[0]: i for i, j in enumerate(mapping) if j}
            end_mapping = {j[-1]: i for i, j in enumerate(mapping) if j}
            token_ids = tokenizer.tokens_to_ids(tokens)
            #print(tokens)
            #print(token_ids)
            for i in range(len(tokens)):
                self.token2text[token_ids[i]]=tokens[i]
            #labels = np.zeros(len(token_ids))
            labels = ['O']*len(token_ids)
            #print(labels)
            for start, end, label in d[1:]:
                if start in start_mapping and end in end_mapping:
                    start = start_mapping[start]
                    end = end_mapping[end]
                    labels[start] = 'B-'+label
                    labels[start + 1:end + 1] = ['I-'+label]*(end-start)
                    # labels[start] = categories_label2id['B-'+label]
                    # labels[start + 1:end + 1] = categories_label2id['I-'+label]
            #print(labels)
            token_ids_.append(token_ids)
            labels_.append(labels)
        token_ids_ =sequence_padding(token_ids_)
        #print(token_ids)
        #labels_ = sequence_padding(labels_)
        return token_ids_,labels_
    def post_postprocess(self,out_infer):
        emission_score, attention_mask=out_infer
        #print(emission_score)
        #print(attention_mask)
        best_path = self.crf.decode(torch.tensor(emission_score,dtype=torch.float), torch.tensor(attention_mask,dtype=torch.float))  # [btz, seq_len]
        return best_path
    def get_input_feed_numpy(self, input_names, inputs):
        """
        input_feed={self.input_name: image_numpy}
        :param input_name:
        :param inputs: image_numpy
        :return:
        """
        input_feed = {}
        for i, (name, input) in enumerate(zip(input_names, inputs)):
            input_feed[name] = np.ascontiguousarray(input)
        return input_feed
    def infer_numpy(self, input_data):
        """
        input_data: [input0, input1, ...]
        Args:
            input_data:

        Returns:

        """
        # logger.debug("input_data shape: {}".format(input_data.shape))
        inputs_feed = self.get_input_feed_numpy(self.input_names[self.graph_names[0]], input_data)
        #print(inputs_feed)
        outputs = self.engine.process(self.graph_names[0], inputs_feed)
        outputs_dict = OrderedDict()
        for name in self.output_names[self.graph_names[0]]:
            outputs_dict[name] = outputs[name]
        # logger.debug(outputs.keys())
        return outputs_dict
        # return self.outputToList_numpy(outputs)
    
    def softmax(self,x):
        """ softmax function """
        
        # assert(len(x.shape) > 1, "dimension must be larger than 1")
        # print(np.max(x, axis = 1, keepdims = True)) # axis = 1, 行
        
        #print(x.shape)
        x = np.exp(x) / np.sum(np.exp(x), axis = 2, keepdims = True)
        #x=x.tolist()
        return x
    def test_1(self,texts):
        
        token_ids=self.pre_process_1(texts)
        #print(token_ids)
        #print(token_ids[0])
        out=self.infer_numpy([[token_ids]])
        #print(out)
        lis=[]
        for i in out.keys():
            lis.append(out[i])
        #print(lis[0])
        lis[0]=self.softmax(lis[0])
        #print(lis[0][0][17])
        #print(lis[0][0][18])
        #print(lis[0].tolist())
        #print(np.max(lis[0],axis=2))
        #print(np.argmax(lis[0],axis=2))
        ans=self.post_postprocess(lis)
        
        ans=self.trans_entity2tuple(ans,token_ids)
        return ans
    def test_b(self,texts):
        y_trues=[]
        y_preds=[]
        token_ids,labels=self.pre_process_batch(texts)
        #print(token_ids[0])
        #print(labels.shape)
        for token_id,label in zip(token_ids,labels):
            
            out=self.infer_numpy([[token_id]])
            #print(out)
            lis=[]
            for i in out.keys():
                lis.append(out[i])
            #print(lis[0])
            lis[0]=self.softmax(lis[0])
            #print(lis[0][0][17])
            #print(lis[0][0][18])
            #print(lis[0].tolist())
            #print(np.max(lis[0],axis=2))
            #print(np.argmax(lis[0],axis=2))
            ans=self.post_postprocess(lis)
            
            ans=self.trans_entity2label(ans)
            # while(1):
            #     try:
            #         label.remove('0')
            #     except:
            #         break
            y_true=label
            y_pred=ans[:len(label)]
            # print(y_true)
            # print(y_pred)
            y_trues.append(y_true)
            y_preds.append(y_pred)
        print("accuary: ", accuracy_score(y_trues, y_preds))
        print("p: ", precision_score(y_trues, y_preds))
        print("r: ", recall_score(y_trues, y_preds))
        print("f1: ", f1_score(y_trues, y_preds))
        print("classification report: ")
        print(classification_report(y_trues, y_preds))

        #return ans,labels
    def trans_entity2label(self,scores):
        entity_ids = []
        for j, item in enumerate(scores[0]):
            flag_tag = categories_id2label[item.item()]
            entity_ids.append(flag_tag)
        return entity_ids
    def trans_entity2tuple(self,scores,token_ids):
        '''把tensor转为(样本id, start, end, 实体类型)的tuple用于计算指标
        '''
        batch_entity_ids = set()
        for i, one_samp in enumerate(scores):
            entity_ids = []
            for j, item in enumerate(one_samp):
                flag_tag = categories_id2label[item.item()]
                if flag_tag.startswith('B-'):  # B
                    entity_ids.append([i, j, j, flag_tag[2:]])
                elif len(entity_ids) == 0:
                    continue
                elif (len(entity_ids[-1]) > 0) and flag_tag.startswith('I-') and (flag_tag[2:]==entity_ids[-1][-1]):  # I
                    entity_ids[-1][-2] = j
                elif len(entity_ids[-1]) > 0:
                    entity_ids.append([])

            for i in entity_ids:
                string=""
                
                if i:
                    for j in range(i[1],i[2]+1):
                        #print(self.token2text[token_ids[j]])
                        string +=self.token2text[token_ids[j]]
                    batch_entity_ids.add(tuple([string,i[3]]))
        return batch_entity_ids
    
# bert=BERT(bmodel_path)
# ans,labels=bert.test(D)
# print(ans)
# bert=BERT(bmodel_path)
# ans,labels=bert.test_b(D)
# print(ans)
def parse_opt():
    parser = argparse.ArgumentParser(prog=__file__)
    parser.add_argument('--model', type=str, default="../data/models/BM1684/fp32model/compilation.bmodel", help='bmodel path')
    parser.add_argument('--dev_id', type=int, default=0, help='device id')
    parser.add_argument('--test_path', type=str, default="../data/china-people-daily-ner-corpus/example.test", help='test_path')
    parser.add_argument('--dict_path', type=str, default="../data/pre_train/chinese-bert-wwm/vocab.txt", help='pre_train_vab_path')

    opt = parser.parse_args()
    return opt
def main(opt):
    bert=BERT(opt.model,opt.dict_path)
    D=dataset.load_data(opt.test_path)
    #print(D)
    bert.test_b(D)
    while(True):
        text=input()
        #bert.test_b(D)
        ans=bert.test_1(text)
        print(ans)
if __name__ == "__main__":
    opt = parse_opt()
    main(opt)
    print('all done.')
