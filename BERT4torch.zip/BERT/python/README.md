# Python例程
- [Python例程](#python例程)
  - [1. 目录](#1-目录)
  - [2. 环境准备](#2-环境准备)
    - [2.1 PCIE模式](#21-pcie模式)
    - [2.2 SOC模式](#22-soc模式)
  - [3. 测试](#3-测试)
    - [3.1 使用说明](#31-使用说明)
    - [3.2 精度结果](#32-精度结果)
      - [3.2.1 fp32bmodel精度](#321-fp32bmodel精度)
      - [3.2.2 int8bmodel精度](#322-int8bmodel精度)
## 1. 目录

​目录结构说明如下，主要使用`BERT_sail.py`：

```
.
├── BERT_sail.py
└── utils           # 依赖

```

## 2. 环境准备

​支持以下环境运行本程序。

### 2.1 PCIE模式

如果您在x86平台安装了PCIe加速卡，并使用它测试本例程，您需要安装libsophon、sophon-opencv、sophon-ffmpeg和sophon-sail,具体请参考[x86-pcie平台的开发和运行环境搭建](../../docs/Environment_Install_Guide.md#2-x86-pcie平台的开发和运行环境搭建)。
此外您可能还需要安装其他第三方库：
```bash
pip3 install bert4torch=0.2.7
pip3 install seqeval=1.2.2
```

### 2.2 SOC模式

如果您使用SoC平台测试本例程，您需要交叉编译安装sophon-sail，具体可参考[交叉编译安装sophon-sail](../../docs/Environment_Install_Guide.md#32-交叉编译安装sophon-sail)。
此外您可能还需要安装其他第三方库：
```bash
pip3 install bert4torch
pip3 install seqeval
```

## 3.  测试

### 3.1 使用说明

python程序默认有一套参数，请注意根据实际情况进行传参，具体参数说明如下：
optional arguments:
  --model MODEL         bmodel path
  --dev_id DEV_ID       device id
  --test_path           test path
  --dict_path           pre_train_vab_path
  --if_crf              if using crf
```bash

usage: python3 BERT_sail.py 


```
demo支持命令行输入，或者

### 3.2 精度结果

注意精度测试需要依赖`seqeval`工具包，安装命令：

```
pip3 install seqeval
```

#### 3.2.1 fp32bmodel精度

​采用人民日报数据集，使用`tools/test_people.py`脚本进行测试，得到精度结果如下（BM1684X、fp32bmodel、PCIE模式，SOC模式数据基本一致）：



运行脚本如下：

```
cd BERT/tools
python3 test_people.py
```


精度结果如下：
pcie
```
accuary:  0.9915143340762013
p:  0.9030256994556273
r:  0.9383057090239411
f1:  0.9203277207922069
classification report: 
              precision    recall  f1-score   support

         LOC       0.92      0.95      0.93      3553
         ORG       0.84      0.90      0.87      2185
         PER       0.95      0.97      0.96      1864

   micro avg       0.90      0.94      0.92      7602
   macro avg       0.90      0.94      0.92      7602
weighted avg       0.90      0.94      0.92      7602
```


soc
```
accuary:  0.99156792775572
p:  0.9005811015664477
r:  0.9377795317021836
f1:  0.9188039695837091
classification report: 
              precision    recall  f1-score   support

         LOC       0.92      0.95      0.93      3553
         ORG       0.83      0.90      0.87      2185
         PER       0.95      0.97      0.96      1864

   micro avg       0.90      0.94      0.92      7602
   macro avg       0.90      0.94      0.92      7602
weighted avg       0.90      0.94      0.92      7602
```


#### 3.2.2 int8bmodel精度
无
