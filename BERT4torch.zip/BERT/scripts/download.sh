#!/bin/bash

pip3 install dfn
pip3 install bert4torch
pip3 install seqeval
root_dir=$(cd `dirname $BASH_SOURCE[0]`/../ && pwd)
model_path=${root_dir}/data/models

pushd ${root_dir}

mkdir -p data
wget http://s3.bmio.net/kashgari/china-people-daily-ner-corpus.tar.gz
tar -zxvf china-people-daily-ner-corpus.tar.gz -C data
rm china-people-daily-ner-corpus.tar.gz


mkdir -p data/models/torch
wget https://media.githubusercontent.com/media/sophgo/model-zoo/main/language/nlp/bert/bert4torch_jit.pt
cp bert4torch_jit.pt data/models/torch
rm bert4torch_jit.pt

mkdir -p data/models/BM1684
wget http://disk-sophgo-vip.quickconnect.cn/sharing/FQtIUAsLs
cp BERT_NER_output_fp32_1b.bmodel data/models/BM1684
rm BERT_NER_output_fp32_1b.bmodel

mkdir -p data/models/BM1684X
wget http://disk-sophgo-vip.quickconnect.cn/sharing/rk80SufFn
cp BERT_NER_output_fp32_1b.bmodel data/models/BM1684X
rm BERT_NER_output_fp32_1b.bmodel

mkdir -p data/pre_train
GIT_LFS_SKIP_SMUDGE=1
git clone https://huggingface.co/bert-base-chinese data/pre_train/chinese-bert-wwm


git clone https://github.com/ericperfect/libtorch_tokenizer.git cpp/libtorch_tokenizer

wget https://download.pytorch.org/libtorch/cpu/libtorch-cxx11-abi-shared-with-deps-2.0.0%2Bcpu.zip
unzip libtorch-cxx11-abi-shared-with-deps-2.0.0+cpu.zip -d cpp
rm libtorch-cxx11-abi-shared-with-deps-2.0.0+cpu.zip
