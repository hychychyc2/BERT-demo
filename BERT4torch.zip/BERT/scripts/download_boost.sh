wget https://boostorg.jfrog.io/artifactory/main/release/1.65.0/source/boost_1_65_0.tar.gz
tar -zxvf boost_1_65_0.tar.gz
rm boost_1_65_0.tar.gz
cd boost_1_65_0
./bootstrap.sh --prefix=../../cpp
sed -i '12c using gcc : : /usr/bin/aarch64-linux-gnu-gcc ; ' project-config.jam 
 ./bjam
 ./bjam install
 cd ..