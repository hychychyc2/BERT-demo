#!/bin/bash

if [ $# -lt 1 ];then
    echo "Erro: please input platform, eg: BM1684"
    popd
    exit -1
fi
maxlen=256
dst_model_prefix="BERT"
platform=$1
echo "start fp32bmodel transform, platform: ${platform} ......"
root_dir=$(cd `dirname $BASH_SOURCE[0]`/../ && pwd)

src_model_file=${root_dir}/data/models/torch/bert4torch_jit.pt
if [ ! -f $src_model_file ]; then
        echo "$src_model_file not exist."
        exit 1
    fi
fp32model_dir="${root_dir}/data/models/${platform}/fp32model"
int8model_dir="${root_dir}/data/models/${platform}/int8model"
if [ ! -d "$fp32model_dir" ]; then
    echo "create data dir: $fp32model_dir"
    mkdir -p $fp32model_dir
fi
python3 -m bmnetp \
      --model="${src_model_file}" \
      --outdir="${fp32model_dir}" \
      --target=${platform} \
      --shapes=[[1,${maxlen}]] \
      --net_name=$dst_model_prefix 
      
