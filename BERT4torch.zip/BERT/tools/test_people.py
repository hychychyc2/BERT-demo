import os
import sys
os.chdir(os.path.abspath(os.path.dirname(sys.argv[0])))
__dir__ = os.path.dirname(os.path.abspath(__file__))
sys.path.append(__dir__)
sys.path.append(__dir__ + "/../")
sys.path.append(__dir__ + "/../python")
from python.BERT_sail import *
# bert=BERT(bmodel_path)
# bert.test_b(D)
def parse_opt():
    parser = argparse.ArgumentParser(prog=__file__)
    parser.add_argument('--model', type=str, default="../data/models/BM1684/fp32model/compilation.bmodel", help='bmodel path')
    parser.add_argument('--dev_id', type=int, default=0, help='device id')
    parser.add_argument('--test_path', type=str, default="../data/china-people-daily-ner-corpus/example.test", help='test_path')

    opt = parser.parse_args()
    return opt
def main(opt):
    bert=BERT(opt.model)
    D=dataset.load_data(opt.test_path)
    bert.test_b(D)
    
if __name__ == "__main__":
    opt = parse_opt()
    main(opt)
    print('all done.')